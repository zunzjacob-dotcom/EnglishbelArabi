package com.example.englishbilarabi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

data class Question(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)
data class Word(val en: String, val ar: String, val example: String)

private val questions = listOf(
    Question("What is your name?", listOf("كم عمرك؟", "ما اسمك؟", "أين تسكن؟", "كيف حالك؟"), 1, "What is your name? تعني: ما اسمك؟"),
    Question("Choose the correct sentence.", listOf("She are happy.", "She am happy.", "She is happy.", "She be happy."), 2, "نستعمل is مع الضمير She."),
    Question("I ____ to work every day.", listOf("go", "goes", "going", "gone"), 0, "مع I نستعمل الفعل في صيغته الأساسية: go."),
    Question("What is the opposite of 'expensive'?", listOf("Cheap", "Big", "Fast", "Early"), 0, "Cheap تعني رخيص، وهي عكس expensive."),
    Question("We have lived here ____ 2020.", listOf("for", "since", "at", "from"), 1, "نستعمل since مع نقطة بداية زمنية محددة."),
    Question("If I had more time, I ____ learn Spanish.", listOf("will", "would", "am", "have"), 1, "في الحالة الافتراضية من النوع الثاني نستعمل would."),
    Question("The report ____ yesterday.", listOf("writes", "wrote", "was written", "has write"), 2, "المبني للمجهول في الماضي: was/were + past participle."),
    Question("Choose the closest meaning of 'reliable'.", listOf("Unusual", "Trustworthy", "Temporary", "Difficult"), 1, "Reliable تعني جدير بالثقة أو يمكن الاعتماد عليه."),
    Question("By the time we arrived, the film ____.", listOf("starts", "has started", "had started", "will start"), 2, "حدث وقع قبل حدث آخر في الماضي: past perfect."),
    Question("Which sentence is most appropriate in a formal email?", listOf("Hey, send it now.", "I want that thing.", "Could you please provide further information?", "Give me details."), 2, "هذه صياغة مهذبة ورسمية لطلب معلومات إضافية.")
)
private val words = listOf(
    Word("Good morning", "صباح الخير", "Good morning, how are you?"),
    Word("Thank you", "شكراً", "Thank you for your help."),
    Word("Work", "عمل", "I go to work at eight."),
    Word("Learn", "يتعلّم", "I want to learn English."),
    Word("Improve", "يحسّن / يطوّر", "I practise every day to improve."),
    Word("Usually", "عادةً", "I usually drink coffee in the morning."),
    Word("Important", "مهم", "English is important for my work."),
    Word("Understand", "يفهم", "I understand the question.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EnglishApp() }
    }
}

@Composable
fun EnglishApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("english_app", 0) }
    var screen by remember { mutableStateOf("home") }
    var level by remember { mutableStateOf(prefs.getString("level", "غير محدد") ?: "غير محدد") }
    var score by remember { mutableIntStateOf(prefs.getInt("score", 0)) }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var qIndex by remember { mutableIntStateOf(0) }
    var correct by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var answered by remember { mutableStateOf(false) }
    var wordIndex by remember { mutableIntStateOf(0) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF2457A7),
            secondary = androidx.compose.ui.graphics.Color(0xFF16A085),
            background = androidx.compose.ui.graphics.Color(0xFFF5F7FB),
            surface = androidx.compose.ui.graphics.Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBarSimple(
                    title = when(screen) {
                        "test" -> "اختبار تحديد المستوى"
                        "lesson" -> "الكلمات اليومية"
                        "progress" -> "تقدّمي"
                        else -> "English بالعربي"
                    },
                    onBack = { screen = "home" }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = screen == "home", onClick = { screen = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected = screen == "lesson", onClick = { screen = "lesson" }, icon = { Icon(Icons.Default.MenuBook, null) }, label = { Text("التعلّم") })
                    NavigationBarItem(selected = screen == "progress", onClick = { screen = "progress" }, icon = { Icon(Icons.Default.Insights, null) }, label = { Text("مستواي") })
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when(screen) {
                    "test" -> PlacementTest(
                        index = qIndex, selected = selected, answered = answered,
                        correct = correct, onSelect = { selected = it },
                        onCheck = { if (selected >= 0 && !answered) { if (selected == questions[qIndex].answer) correct++; answered = true } },
                        onNext = {
                            if (qIndex < questions.lastIndex) { qIndex++; selected = -1; answered = false }
                            else {
                                score = correct * 10
                                level = when {
                                    correct <= 2 -> "A1 – مبتدئ"
                                    correct <= 4 -> "A2 – مبتدئ متقدم"
                                    correct <= 6 -> "B1 – متوسط"
                                    correct <= 8 -> "B2 – متوسط متقدم"
                                    else -> "C1/C2 – متقدم (يحتاج اختباراً أعمق)"
                                }
                                prefs.edit().putInt("score", score).putString("level", level).apply()
                                screen = "result"
                            }
                        }
                    )
                    "result" -> ResultScreen(level, score, onHome = { screen = "home" }, onRetry = { qIndex = 0; correct = 0; selected = -1; answered = false; screen = "test" })
                    "lesson" -> LessonScreen(wordIndex, onPrevious = { if (wordIndex > 0) wordIndex-- }, onNext = { if (wordIndex < words.lastIndex) wordIndex++ }, onDone = { completed++; prefs.edit().putInt("completed", completed).apply(); screen = "progress" })
                    "progress" -> ProgressScreen(level, score, completed, onTest = { qIndex = 0; correct = 0; selected = -1; answered = false; screen = "test" })
                    "skills" -> SkillsAssessmentScreen(onBack = { screen = "home" })
                    else -> HomeScreen(level, score, completed, onTest = { qIndex = 0; correct = 0; selected = -1; answered = false; screen = "test" }, onLesson = { screen = "lesson" }, onProgress = { screen = "progress" }, onSkills = { screen = "skills" })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarSimple(title: String, onBack: () -> Unit) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") } }
    )
}

@Composable
fun HomeScreen(level: String, score: Int, completed: Int, onTest: () -> Unit, onLesson: () -> Unit, onProgress: () -> Unit, onSkills: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.End) {
                Text("مرحباً بك في رحلتك لتعلّم الإنجليزية", color = androidx.compose.ui.graphics.Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                Spacer(Modifier.height(8.dp))
                Text("تعلّم خطوة بخطوة، من العربية إلى الإنجليزية.", color = androidx.compose.ui.graphics.Color.White.copy(alpha = .9f), textAlign = TextAlign.End)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onTest, colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color.White, contentColor = MaterialTheme.colorScheme.primary)) { Text("ابدأ اختبار تحديد المستوى") }
            }
        }
        Text("ملخّص تعلّمك", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryCard("مستواك", level, Modifier.weight(1f))
            SummaryCard("نتيجة الاختبار", "$score / 100", Modifier.weight(1f))
            SummaryCard("دروس مكتملة", "$completed", Modifier.weight(1f))
        }
        Text("ابدأ التعلّم", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        ActionCard("📚", "كلمات وجمل يومية", "تعلّم مفردات مع ترجمتها وأمثلة", onLesson)
        ActionCard("🎯", "اختبار المهارات الخمس", "القواعد والقراءة والاستماع والكتابة والتحدث", onSkills)
        ActionCard("📊", "متابعة المستوى", "راجع نتيجتك وتقدّمك", onProgress)
        Text("نصيحة: خصّص 10 إلى 15 دقيقة يومياً للتعلّم والمراجعة.", color = MaterialTheme.colorScheme.secondary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
    }
}

@Composable
fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(5.dp))
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun ActionCard(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text(emoji, fontSize = 26.sp)
        }
    }
}

@Composable
fun PlacementTest(index: Int, selected: Int, answered: Boolean, correct: Int, onSelect: (Int) -> Unit, onCheck: () -> Unit, onNext: () -> Unit) {
    val q = questions[index]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), horizontalAlignment = Alignment.End) {
        Text("السؤال ${index + 1} من ${questions.size}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        LinearProgressIndicator(progress = { (index + 1).toFloat() / questions.size }, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
        Text("اختر الإجابة الصحيحة", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(18.dp)) {
            Text(q.prompt, Modifier.fillMaxWidth().padding(20.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(14.dp))
        q.options.forEachIndexed { i, option ->
            Card(
                onClick = { if (!answered) onSelect(i) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                colors = CardDefaults.cardColors(
                    containerColor = when {
                        answered && i == q.answer -> androidx.compose.ui.graphics.Color(0xFFDDF4E5)
                        answered && i == selected && i != q.answer -> androidx.compose.ui.graphics.Color(0xFFFFE1E1)
                        selected == i -> MaterialTheme.colorScheme.primaryContainer
                        else -> MaterialTheme.colorScheme.surface
                    }
                )
            ) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected == i, onClick = { if (!answered) onSelect(i) })
                    Spacer(Modifier.width(8.dp))
                    Text(option, Modifier.weight(1f), textAlign = TextAlign.End)
                }
            }
        }
        if (answered) {
            Spacer(Modifier.height(8.dp))
            Text(q.explanation, color = MaterialTheme.colorScheme.secondary, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = if (answered) onNext else onCheck, enabled = selected >= 0, modifier = Modifier.fillMaxWidth()) {
            Text(if (answered) if (index == questions.lastIndex) "عرض النتيجة" else "السؤال التالي" else "تحقّق من الإجابة")
        }
    }
}

@Composable
fun ResultScreen(level: String, score: Int, onHome: () -> Unit, onRetry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("أحسنت! أكملت الاختبار", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Text("$score / 100", fontSize = 42.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text("التقدير الأولي لمستواك", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Text(level, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("هذه نتيجة تشخيصية أولية مبنية على أسئلة قصيرة، وليست شهادة أو تقييماً رسمياً معتمداً. يلزم اختبار أوسع يشمل الاستماع والتحدث والكتابة لتحديد المستوى بدقة.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onHome, modifier = Modifier.fillMaxWidth()) { Text("العودة إلى الرئيسية") }
        OutlinedButton(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text("إعادة الاختبار") }
    }
}

@Composable
fun LessonScreen(index: Int, onPrevious: () -> Unit, onNext: () -> Unit, onDone: () -> Unit) {
    val w = words[index]
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("المفردات الأساسية • ${index + 1}/${words.size}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        LinearProgressIndicator(progress = { (index + 1).toFloat() / words.size }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(28.dp))
        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(w.en, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(14.dp))
                Text(w.ar, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(24.dp))
                Divider()
                Spacer(Modifier.height(18.dp))
                Text("مثال في جملة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(w.example, fontSize = 18.sp, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onPrevious, enabled = index > 0, modifier = Modifier.weight(1f)) { Text("السابق") }
            Button(onClick = onNext, enabled = index < words.lastIndex, modifier = Modifier.weight(1f)) { Text("التالي") }
        }
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("إنهاء الدرس") }
    }
}

@Composable
fun ProgressScreen(level: String, score: Int, completed: Int, onTest: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("ملفك التعليمي", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.End) {
                Text("المستوى التقديري", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(level, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(14.dp))
                Text("نتيجة آخر اختبار: $score / 100")
                Text("الدروس التي أنهيتها: $completed")
            }
        }
        Text("كيف تطوّر مستواك؟", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("• أعد اختبار المستوى بعد إكمال الدروس.\n• راجع الكلمات التي تعلمتها.\n• أضف تدريبات الاستماع والمحادثة والكتابة إلى برنامجك.")
        Button(onClick = onTest, modifier = Modifier.fillMaxWidth()) { Text("إجراء اختبار جديد") }
        Text("ملاحظة: النسخة الحالية تحفظ التقدم على هذا الجهاز فقط.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}
