package com.example.englishbilarabi

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.runtime.DisposableEffect
import java.util.Locale

private data class SkillQuestion(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)

private val grammarQs = listOf(
    SkillQuestion("She ____ to work every morning.", listOf("go", "goes", "going", "gone"), 1, "مع She في المضارع البسيط نضيف s إلى الفعل: goes."),
    SkillQuestion("If I had more time, I ____ travel.", listOf("will", "would", "am", "have"), 1, "في الحالة الافتراضية الثانية نستعمل would.")
)
private val readingQs = listOf(
    SkillQuestion("Why does Sara walk to work?", listOf("To save money", "To meet friends", "Because she is late", "For exercise only"), 0, "النص يذكر أنها تمشي إلى العمل لتوفير المال."),
    SkillQuestion("What does Sara do after work?", listOf("Goes shopping", "Studies English", "Visits her sister", "Plays football"), 1, "بعد العمل تدرس الإنجليزية لمدة نصف ساعة.")
)
private val listeningQs = listOf(
    SkillQuestion("Where does Tom work?", listOf("At a hospital", "At a school", "At a bank", "At a hotel"), 2, "في المقطع المسموع يقول Tom إنه يعمل في بنك."),
    SkillQuestion("How does he go to work?", listOf("By car", "By bus", "On foot", "By train"), 1, "يقول إنه يذهب إلى العمل بالحافلة.")
)

@Composable
fun SkillsAssessmentScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("english_app", 0) }
    val tts = remember(context) { TextToSpeech(context, null) }
    DisposableEffect(tts) { onDispose { tts.stop(); tts.shutdown() } }

    var grammar by remember { mutableStateOf(mapOf<Int, Int>()) }
    var reading by remember { mutableStateOf(mapOf<Int, Int>()) }
    var listening by remember { mutableStateOf(mapOf<Int, Int>()) }
    var writing by remember { mutableStateOf("") }
    var speaking by remember { mutableIntStateOf(0) }
    var saved by remember { mutableStateOf(false) }

    val readingText = "Sara works in a small office in Tunis. She usually walks to work because she wants to save money. After work, she studies English for thirty minutes. At weekends, she visits her family."
    val listeningText = "Hello, my name is Tom. I work at a bank in the city centre. I usually take the bus to work because parking is expensive."

    fun score(answers: Map<Int, Int>, qs: List<SkillQuestion>): Int =
        qs.indices.count { answers[it] == qs[it].answer } * 100 / qs.size

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Spacer(Modifier.weight(1f))
            Text("اختبار المهارات الخمس", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Text("أجب دون استعمال الترجمة أو القاموس. هذا اختبار تشخيصي أولي، وليس شهادة رسمية.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End)

        SkillQuestionCard("1. القواعد والمفردات", grammarQs, grammar) { grammar = grammar + (it.first to it.second) }

        Card(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("2. القراءة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(readingText, textAlign = TextAlign.Start, modifier = Modifier.fillMaxWidth())
                SkillQuestionOptions(readingQs, reading) { reading = reading + (it.first to it.second) }
            }
        }

        Card(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("3. الاستماع", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("استمع إلى المقطع دون قراءة النص، ثم أجب عن السؤالين.", textAlign = TextAlign.End)
                Button(onClick = {
                    tts.language = Locale.UK
                    tts.setSpeechRate(0.85f)
                    tts.speak(listeningText, TextToSpeech.QUEUE_FLUSH, null, "listening_assessment")
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("استمع إلى المقطع الإنجليزي")
                }
                SkillQuestionOptions(listeningQs, listening) { listening = listening + (it.first to it.second) }
                Text("يعتمد الصوت على محرك النطق المتاح في هاتف Android.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("4. الكتابة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("اكتب فقرة من 5 إلى 8 جمل باللغة الإنجليزية عن يومك المعتاد. في هذه النسخة تُحفظ العينة، لكن لا تُمنح علامة آلية لجودة اللغة.", textAlign = TextAlign.End)
                OutlinedTextField(
                    value = writing, onValueChange = { writing = it; saved = false },
                    modifier = Modifier.fillMaxWidth(), minLines = 5,
                    placeholder = { Text("I usually wake up at...") }
                )
                Text("عدد الكلمات: ${writing.trim().split(Regex("\\s+")).count { it.isNotBlank() }}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("5. التحدث", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("تحدث بصوت مسموع لمدة دقيقة: عرّف بنفسك، تحدث عن عملك أو دراستك، ثم اذكر هدفك من تعلم الإنجليزية.", textAlign = TextAlign.End)
                Text("قيّم أداءك الذاتي: 1 صعب جداً — 5 تحدثت بسهولة وبجمل مترابطة", fontSize = 12.sp)
                Slider(value = speaking.toFloat(), onValueChange = { speaking = it.toInt(); saved = false }, valueRange = 1f..5f, steps = 3)
                Text(if (speaking == 0) "لم يتم التقييم بعد" else "تقييمك: $speaking من 5")
                Text("هذا تقييم ذاتي، وليس تحليلاً آلياً للنطق. التسجيل وتحليل النطق سيضافان في مرحلة لاحقة.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End)
            }
        }

        val ready = grammar.size == grammarQs.size && reading.size == readingQs.size &&
            listening.size == listeningQs.size && writing.trim().isNotEmpty() && speaking > 0
        Button(
            onClick = {
                prefs.edit()
                    .putInt("skill_grammar", score(grammar, grammarQs))
                    .putInt("skill_reading", score(reading, readingQs))
                    .putInt("skill_listening", score(listening, listeningQs))
                    .putString("skill_writing", writing)
                    .putInt("skill_speaking", speaking)
                    .apply()
                saved = true
            },
            enabled = ready, modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ نتائج المهارات") }

        if (saved) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("تم حفظ نتائجك على هذا الهاتف", fontWeight = FontWeight.Bold)
                    Text("القواعد: ${score(grammar, grammarQs)} / 100")
                    Text("القراءة: ${score(reading, readingQs)} / 100")
                    Text("الاستماع: ${score(listening, listeningQs)} / 100")
                    Text("الكتابة: عينة محفوظة للمراجعة")
                    Text("التحدث: تقييم ذاتي $speaking / 5")
                }
            }
        }
    }
}

@Composable
private fun SkillQuestionCard(title: String, questions: List<SkillQuestion>, answers: Map<Int, Int>, onAnswer: (Pair<Int, Int>) -> Unit) {
    Card(shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            SkillQuestionOptions(questions, answers, onAnswer)
        }
    }
}

@Composable
private fun SkillQuestionOptions(questions: List<SkillQuestion>, answers: Map<Int, Int>, onAnswer: (Pair<Int, Int>) -> Unit) {
    questions.forEachIndexed { index, q ->
        Text(q.prompt, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        q.options.forEachIndexed { optionIndex, option ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = answers[index] == optionIndex, onClick = { onAnswer(index to optionIndex) })
                Text(option, Modifier.weight(1f), textAlign = TextAlign.End)
            }
        }
        if (answers.containsKey(index)) {
            Text(q.explanation, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
        }
    }
}
